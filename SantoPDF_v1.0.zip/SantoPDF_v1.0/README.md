# SantoPDF v1.0 - AI Document Assistant

Thank you for purchasing SantoPDF! This tool allows you to chat with your PDF documents using Google's Gemini Pro AI.

## ⚡ Quick Start (Windows)
1.  **Unzip** this folder to your Desktop.
2.  **Get your API Key:**
    * Go to: https://aistudio.google.com/app/apikey
    * Create a free API key.
3.  **Setup the Key:**
    * Open the file named `.env.example` with Notepad.
    * Paste your key where it says `PASTE YOUR OWN KEY HERE`.
    * Save the file.
    * **Rename** the file from `.env.example` to `.env` (Remove the .example part).
4.  **Launch:**
    * Double-click the `run.bat` file.
    * Wait for the installation to finish. The app will open in your browser automatically.

## 🐳 Docker Instructions (Advanced Users)
If you prefer running via Docker, we have included a production-ready setup.
1.  Open a terminal in this folder.
2.  Build: `docker build -t santopdf .`
3.  Run: `docker run -p 8501:8501 --env-file .env santopdf`

## Need Help?
Contact support at: Contact me via the Gumroad product page